'use client';

import { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Calendar, Droplets, Sun, Wind, Sprout, Wheat, CheckCircle2, Download } from 'lucide-react';

interface PlanWeek {
  week: number;
  tamilMonth: string;
  gregorianDate: string;
  panchangam: {
    tithi: string;
    nakshatra: string;
    auspicious: boolean;
  };
  satellite: {
    ndvi: number;
    moisture: string;
  };
  task: string;
  tamilTask: string;
}

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [plan, setPlan] = useState<PlanWeek[]>([]);
  const [language, setLanguage] = useState<'en' | 'ta'>('en');

  useEffect(() => {
    // Simulate API call to orchestrator
    setTimeout(() => {
      setPlan([
        {
          week: 1, tamilMonth: 'Chithirai (சித்திரை)', gregorianDate: 'May 20',
          panchangam: { tithi: 'Dvitiya', nakshatra: 'Rohini', auspicious: true },
          satellite: { ndvi: 0.2, moisture: 'Low' },
          task: 'Land Preparation & Sowing. Auspicious day due to Rohini Nakshatra.',
          tamilTask: 'நிலம் தயாரித்தல் மற்றும் விதைத்தல். ரோகிணி நட்சத்திரத்தால் உகந்த நாள்.'
        },
        {
          week: 2, tamilMonth: 'Chithirai (சித்திரை)', gregorianDate: 'May 27',
          panchangam: { tithi: 'Navami', nakshatra: 'Magha', auspicious: false },
          satellite: { ndvi: 0.3, moisture: 'Medium' },
          task: 'First irrigation. Avoid major new activities (Navami).',
          tamilTask: 'முதல் நீர்ப்பாசனம். புதிய முக்கிய செயல்களை தவிர்க்கவும்.'
        },
        {
          week: 4, tamilMonth: 'Vaikasi (வைகாசி)', gregorianDate: 'Jun 10',
          panchangam: { tithi: 'Purnima', nakshatra: 'Anuradha', auspicious: true },
          satellite: { ndvi: 0.65, moisture: 'Optimal' },
          task: 'Apply fertilizers. NDVI indicates good early growth.',
          tamilTask: 'உரம் இடுதல். பயிர் வளர்ச்சி நன்றாக உள்ளது.'
        },
        {
          week: 16, tamilMonth: 'Avani (ஆவணி)', gregorianDate: 'Sep 05',
          panchangam: { tithi: 'Dashami', nakshatra: 'Uttara Ashadha', auspicious: true },
          satellite: { ndvi: 0.85, moisture: 'Low' },
          task: 'Harvesting begins. Dry conditions and auspicious timing.',
          tamilTask: 'அறுவடை தொடக்கம். உகந்த நேரம்.'
        }
      ]);
      setLoading(false);
    }, 2000);
  }, []);

  const chartData = [
    { name: 'W1', ndvi: 0.2 },
    { name: 'W2', ndvi: 0.3 },
    { name: 'W3', ndvi: 0.5 },
    { name: 'W4', ndvi: 0.65 },
    { name: 'W8', ndvi: 0.8 },
    { name: 'W12', ndvi: 0.9 },
    { name: 'W16', ndvi: 0.85 },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center space-y-6 bg-background">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        <p className="text-xl font-medium text-foreground animate-pulse">
          Consulting Panchangam & Satellite Data...
          <br/><span className="text-sm text-foreground/70">பஞ்சாங்கம் மற்றும் செயற்கைக்கோள் தரவுகளை ஆய்வு செய்கிறது...</span>
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 sm:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-card p-6 rounded-2xl shadow-sm border border-primary/10">
          <div>
            <h1 className="text-3xl font-bold text-primary">Coimbatore Paddy Plan</h1>
            <p className="text-foreground/70">120-day cycle optimized via AI</p>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
              className="px-4 py-2 bg-secondary/20 text-secondary-foreground font-semibold rounded-lg hover:bg-secondary/30 transition"
            >
              {language === 'en' ? 'தமிழ்' : 'English'}
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground font-semibold rounded-lg shadow hover:bg-primary/90 transition">
              <Download size={18} />
              Export
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Timeline */}
          <div className="lg:col-span-2 space-y-6">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Calendar className="text-primary" /> 
              {language === 'en' ? 'Weekly Action Plan' : 'வாராந்திர செயல் திட்டம்'}
            </h2>
            
            <div className="space-y-4 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-primary/30 before:to-transparent">
              {plan.map((p, i) => (
                <div key={i} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-background bg-primary text-primary-foreground shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                    {i === 0 ? <Sprout size={18} /> : i === plan.length - 1 ? <Wheat size={18} /> : <CheckCircle2 size={18} />}
                  </div>
                  
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-card p-5 rounded-2xl shadow-sm border border-primary/10 hover:shadow-md transition duration-300">
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-sm font-bold text-accent bg-accent/10 px-2 py-1 rounded">Week {p.week}</span>
                      <span className="text-sm text-foreground/60">{p.gregorianDate} • {p.tamilMonth}</span>
                    </div>
                    <h3 className="text-lg font-semibold mb-2">
                      {language === 'en' ? p.task : p.tamilTask}
                    </h3>
                    <div className="flex gap-4 text-sm mt-4 pt-4 border-t border-primary/5">
                      <span className="flex items-center gap-1 text-primary">
                        <Sun size={14} /> {p.panchangam.nakshatra}
                      </span>
                      <span className="flex items-center gap-1 text-blue-500">
                        <Droplets size={14} /> {p.satellite.moisture}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sidebar / Visuals */}
          <div className="space-y-8">
            <div className="bg-card p-6 rounded-2xl shadow-sm border border-primary/10">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Wind className="text-primary" /> 
                {language === 'en' ? 'Crop Health (NDVI)' : 'பயிர் ஆரோக்கியம் (NDVI)'}
              </h3>
              <div className="h-48 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--foreground)/0.1)" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--foreground)/0.5)'}} />
                    <YAxis domain={[0, 1]} axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--foreground)/0.5)'}} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                      itemStyle={{ color: 'hsl(var(--foreground))' }}
                    />
                    <Line type="monotone" dataKey="ndvi" stroke="hsl(var(--primary))" strokeWidth={3} dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <p className="text-xs text-center text-foreground/50 mt-2">Predicted vegetation index over time</p>
            </div>

            <div className="bg-gradient-to-br from-primary to-primary/80 p-6 rounded-2xl shadow-lg text-primary-foreground">
              <h3 className="text-xl font-bold mb-2">Ask KisriKaala AI</h3>
              <p className="text-sm text-primary-foreground/80 mb-4">Voice input supported in Tamil.</p>
              <button className="w-full bg-background/20 hover:bg-background/30 transition py-3 rounded-xl flex items-center justify-center gap-2 font-semibold">
                🎤 {language === 'en' ? 'Tap to Speak' : 'பேச அழுத்தவும்'}
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

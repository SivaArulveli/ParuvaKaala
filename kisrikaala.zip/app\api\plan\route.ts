import { NextResponse } from 'next/server';
import { generateCropPlan } from '@/lib/agent';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { crop, location, startDate } = body;
    
    const plan = await generateCropPlan(crop, location, new Date(startDate || Date.now()));
    
    return NextResponse.json({ success: true, plan });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Failed to generate plan' }, { status: 500 });
  }
}

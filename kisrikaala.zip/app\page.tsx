'use client';

import { useState } from 'react';
import Dashboard from '@/components/Dashboard';

export default function Home() {
  const [started, setStarted] = useState(false);

  if (started) {
    return <Dashboard />;
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-6 sm:p-24 relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background"></div>
      
      <div className="z-10 max-w-5xl w-full flex flex-col items-center gap-8 text-center">
        <h1 className="text-5xl sm:text-7xl font-extrabold tracking-tight text-primary drop-shadow-sm">
          KisriKaala <br/>
          <span className="text-4xl sm:text-6xl text-secondary">கிசிரி காலம்</span>
        </h1>
        
        <p className="text-xl text-foreground/80 max-w-2xl font-medium">
          Predict seeding, harvesting, and your full crop cycle using ancient Panchangam mathematics combined with the latest satellite data.
        </p>

        <div className="w-full max-w-md space-y-4 bg-card p-8 rounded-2xl shadow-xl border border-primary/10 mt-8 backdrop-blur-sm bg-card/90">
          <div className="space-y-2 text-left">
            <label className="text-sm font-semibold text-foreground/90 ml-1">Crop Type</label>
            <select className="w-full p-3 rounded-xl border border-primary/20 bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all">
              <option value="paddy">Paddy (நெல்)</option>
              <option value="sugarcane">Sugarcane (கரும்பு)</option>
              <option value="coconut">Coconut (தேங்காய்)</option>
              <option value="banana">Banana (வாழை)</option>
              <option value="millets">Millets (தினை)</option>
              <option value="vegetables">Vegetables (காய்கறிகள்)</option>
            </select>
          </div>

          <div className="space-y-2 text-left">
            <label className="text-sm font-semibold text-foreground/90 ml-1">Location</label>
            <select className="w-full p-3 rounded-xl border border-primary/20 bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all">
              <option value="coimbatore">Coimbatore (கோயம்புத்தூர்)</option>
              <option value="madurai">Madurai (மதுரை)</option>
              <option value="trichy">Trichy (திருச்சி)</option>
              <option value="salem">Salem (சேலம்)</option>
              <option value="tirunelveli">Tirunelveli (திருநெல்வேலி)</option>
              <option value="gps">Use GPS Location (ஜி.பி.எஸ்)</option>
            </select>
          </div>

          <button 
            onClick={() => setStarted(true)}
            className="w-full mt-6 bg-primary hover:bg-primary/90 text-primary-foreground font-bold py-4 px-6 rounded-xl transition-all active:scale-95 shadow-lg shadow-primary/25"
          >
            Generate AI Plan (திட்டத்தை உருவாக்கு)
          </button>
        </div>
      </div>
    </main>
  );
}
